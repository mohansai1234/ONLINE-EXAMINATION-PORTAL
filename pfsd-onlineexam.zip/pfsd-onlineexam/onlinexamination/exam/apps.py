from django.apps import AppConfig
from django.db import connection


class examConfig(AppConfig):
    name = 'exam'

    def ready(self):
        # Set the time zone to UTC using Django's database connection
        with connection.cursor() as cursor:
            cursor.execute("SET TIME ZONE 'UTC';")
